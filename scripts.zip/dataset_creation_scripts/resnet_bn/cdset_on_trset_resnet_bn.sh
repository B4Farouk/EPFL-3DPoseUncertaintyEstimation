RESPATH="/home/boukil/project/results/$1/"
CODEPATH="/home/boukil/project/codebase/"
DATAPATH="/home/boukil/project/data/"
source /home/boukil/project/venv/bin/activate
python3 "$CODEPATH""main.py" \
	--dataset_name h36m \
	--experimental_setup fully \
	--batch_size_test 8 \
	--type_lifting_network "resnet" \
	--lifting_backbone_normalization "batch" \
	--load_from_checkpoint \
	--checkpoint_path "$RESPATH""models/model_best-uncertainty_loss.pth.tar" \
	--num_workers 4 \
	--save_dir "$RESPATH" \
	--finetune_with_lifting_net \
	--calibration_folder "$CODEPATH""calibration/h36m" \
	--load_from_cache \
	--path_cache_h36m  "$DATAPATH""cache" \
	--predictions_data_test_file "$DATAPATH""R50-DUC-NO-WT-PRE-H36M-ALL-BEST-test.json" \
	--lifting_use_gt_2d_keypoints \
	--predictions_data_train_file "$DATAPATH""R50-DUC-NO-WT-PRE-H36M-ALL-BEST-train.json" \
	--annotated_subjects S1 S5 S6 S7 S8 \
	--train_with_annotations_only \
	--create_stats_dataset \
	--stats_dataset_savepath "$RESPATH""stats_datasets/stats_dataset_from_train_set.json" \