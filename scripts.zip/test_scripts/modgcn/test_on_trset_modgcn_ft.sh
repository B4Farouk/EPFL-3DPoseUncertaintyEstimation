RESPATH="/home/boukil/project/results/$1/"
CODEPATH="/home/boukil/project/codebase/"
DATAPATH="/home/boukil/project/data/"
PROJ=$2
echo "[INFO]: Will be testing the best model in $RESPATH with $PROJ projection."
source /home/boukil/project/venv/bin/activate
python3 "$CODEPATH""main.py" \
	--dataset_name h36m \
	--experimental_setup fully \
	--batch_size_test 8 \
	--perform_test \
	--load_from_checkpoint \
	--type_lifting_network "modulated_gcn" \
	--checkpoint_path "$RESPATH""models/model_best-uncertainty_loss.pth.tar" \
	--num_workers 4 \
	--save_dir "$RESPATH" \
	--finetune_with_lifting_net \
	--calibration_folder "$CODEPATH""calibration/h36m" \
	--load_from_cache \
	--path_cache_h36m  "$DATAPATH""cache" \
	--predictions_data_test_file "$DATAPATH""R50-DUC-NO-WT-PRE-H36M-ALL-BEST-test.json" \
	--lifting_use_gt_2d_keypoints \
	--uncertainty_plots \
	--uncertainty_plots_dim "$PROJ" \
	--uncertainty_plots_match_pred_to_gt_keypoints \
	--uncertainty_plots_normalize_coords \
	--test_on_training_set \
	--annotated_subjects S1 S5 S6 S7 S8 \
	--train_with_annotations_only \
	--predictions_data_train_file "$DATAPATH""R50-DUC-NO-WT-PRE-H36M-ALL-BEST-train.json" \
	
	