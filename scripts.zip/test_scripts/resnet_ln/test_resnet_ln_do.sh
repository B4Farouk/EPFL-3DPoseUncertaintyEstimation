RESPATH="/home/boukil/project/results/$1/"
CODEPATH="/home/boukil/project/codebase/"
DATAPATH="/home/boukil/project/data/"
PROJ=$2
echo "[INFO]: Will be testing the best model in $RESPATH with $PROJ projection."
source /home/boukil/project/venv/bin/activate
python3 "$CODEPATH""main.py" \
	--dataset_name h36m \
	--experimental_setup fully \
	--batch_size_test 8 \
	--perform_test \
	--load_from_checkpoint \
	--type_lifting_network "resnet" \
	--lifting_backbone_normalization "layer" \
	--checkpoint_path "$RESPATH""models/model_best-3d_sv_mpjpe.pth.tar" \
	--num_workers 4 \
	--save_dir "$RESPATH" \
	--finetune_with_lifting_net \
	--calibration_folder "$CODEPATH""calibration/h36m" \
	--load_from_cache \
	--path_cache_h36m  "$DATAPATH""cache" \
	--predictions_data_test_file "$DATAPATH""R50-DUC-NO-WT-PRE-H36M-ALL-BEST-test.json" \
	--lifting_use_gt_2d_keypoints \
	--uncertainty_plots \
	--uncertainty_plots_dim "$PROJ" \
	--uncertainty_plots_match_pred_to_gt_keypoints \
	--uncertainty_plots_normalize_coords \