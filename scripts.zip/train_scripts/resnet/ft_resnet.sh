CLUSPATH="/home/boukil/project/" 
RESPATH="$CLUSPATH""results/$1/"
source "$CLUSPATH""venv/bin/activate"
python3 "$CLUSPATH""codebase/main.py" \
	--dataset_name "h36m" \
	--experimental_setup "fully" \
	--batch_size 64 \
	--batch_size_test 16 \
	--annotated_subjects S1 S5 S6 S7 S8 \
	--train_with_annotations_only \
	--randomize \
	--shuffle \
	--type_lifting_network "resnet" \
	--train_lifting_net \
	--lr_lifting_net 0.00005 \
	--wd_lifting_net 0.00001 \
	--optimizer "sgd" \
	--scheduler "cyclic" \
	--clip_grad_by_norm \
	--clip_grad_by_norm_val 0.2 \
	--size_average \
	--epochs 20 \
	--num_workers 4 \
	--eval_freq 500 \
	--load_from_checkpoint \
	--checkpoint_path "$RESPATH""models/model_best-3d_sv_mpjpe.pth.tar" \
	--save_dir "$CLUSPATH""results/12-12-23-resnet-2b1h2l-272-272-ft" \
	--save_model_freq 5 \
	--use_batch_norm_mlp \
	--encoder_dropout 0.1 \
	--finetune_with_lifting_net \
	--predictions_data_train_file "$CLUSPATH""data/R50-DUC-NO-WT-PRE-H36M-ALL-BEST-train.json" \
	--predictions_data_test_file "$CLUSPATH""data/R50-DUC-NO-WT-PRE-H36M-ALL-BEST-test.json" \
	--calibration_folder "$CLUSPATH""codebase/calibration/h36m" \
	--load_from_cache \
	--path_cache_h36m  "$CLUSPATH""data/cache" \
	--calculate_uncertainty_loss \
	--lifting_use_gt_2d_keypoints